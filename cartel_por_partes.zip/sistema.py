

def sistem(sujeto):
    if sujeto == "dead":
        return True
    else:
        return False